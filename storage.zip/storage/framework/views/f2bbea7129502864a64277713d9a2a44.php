

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
             <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('success1')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success1')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('danger')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('danger')); ?>

            </div>
            <?php endif; ?>
            <div class="col-md-10">
                <div class="pull-right">
                    <a class="btn btn-primary shadow-none" data-toggle="tooltip" data-placement="top" title="Agregar Area" href="<?php echo e(route('areas.create')); ?>"> 
                        <i class="fa fa-plus"></i>
                    </a>
                </div>
                
            </div>
            
            <div class="col-md-10">
                <?php if(sizeof($areas)>0): ?>
                <div class="table-responsive">
            <table class="table table-hover">
            <thead>
            <tr>
                <th scope="col">Acciones</th>
                <th scope="col">#</th>
                <th scope="col">Areas</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center" width="20%">
                        <a href="<?php echo e(route('areas.show',$area)); ?>" class="btn btn-info btn-sm shadow-none" 
                                data-toggle="tooltip" data-placement="top" title="Ver detalles">
                            <i class="fa fa-book fa-fw text-white"></i></a>
                        </a>
                        <a href="<?php echo e(route('areas.edit',$area)); ?>" class="btn btn-warning btn-sm shadow-none" 
                                data-toggle="tooltip" data-placement="top" title="Editar Area">
                            <i class="fa fa-pencil fa-fw text-white"></i></a>
                        </a>
                        <form action="<?php echo e(route('areas.destroy',$area)); ?>" method="POST" class="d-inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>    
                        <button id="delete" name="delete" type="submit" 
                                    class="btn btn-dark btn-sm shadow-none" 
                                    data-toggle="tooltip" data-placement="top" title="Eliminar Area"
                                    onclick="return confirm('¿Estás seguro de eliminar?')">
                                <i class="fa fa-trash-o fa-fw"></i>
                            </button>
                        </form>
                    </td>
                    <td scope="row"><?php echo e($area->id_area); ?></td>
                    <td scope="row"><?php echo e($area->nombre_area); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center">
        <?php echo $areas->links(); ?>

        </div>
    </div>
    <?php else: ?>
        <div class="alert alert-secondary">No se encontraron registros</div>
    <?php endif; ?>
    </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mi_app\resources\views/areas/index.blade.php ENDPATH**/ ?>