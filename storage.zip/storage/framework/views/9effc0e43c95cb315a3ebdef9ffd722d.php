

<?php $__env->startSection('content'); ?>
    
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="pull-right">
                <a class="btn btn-primary shadow-none" data-toggle="tooltip" data-placement="top" 
                title="Inicio" href="<?php echo e(route('empleados.index')); ?>"> 
                    <i class="fa fa-home fa-fw"></i> 
                </a>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card mx-auto" style="width: 50%;">
              <div class="card-header">
                Empleado
              </div>
              <div class="card-body text-center">
                <h5 class="card-title"><b><?php echo e($empleado->nombre_empleado); ?></b></h5>
                <h5 class="card-title"><b>Puesto: <?php echo e($empleado->puesto); ?></b></h5>
                <h5 class="card-title"><b>Email: <?php echo e($empleado->email); ?></b></h5>
                <h5 class="card-title"><b>Num. Telefono <?php echo e($empleado->telefono); ?></b></h5>
              </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mi_app\resources\views/empleados/show.blade.php ENDPATH**/ ?>