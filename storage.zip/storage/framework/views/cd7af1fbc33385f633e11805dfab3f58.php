

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
             <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('success1')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success1')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('danger')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('danger')); ?>

            </div>
            <?php endif; ?>
            <div class="col-md-10">
                <div class="pull-right">
                    <a class="btn btn-primary shadow-none" data-toggle="tooltip" data-placement="top" title="Agregar periodo" href="<?php echo e(route('periodos.create')); ?>"> 
                        <i class="fa fa-plus"></i>
                    </a>
                </div>
            </div>
           
            <div class="col-md-10">
                <?php if(sizeof($periodos)>0): ?>
                <div class="table-responsive">
            <table class="table table-hover">
            <thead>
            <tr>
                <th scope="col">Acciones</th>
                <th scope="col">#</th>
                <th scope="col">Periodos</th>
                <th scope="col">Estado</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center" width="20%">
                        
                        <a href="<?php echo e(route('periodos.edit',$periodo)); ?>" class="btn btn-info btn-sm shadow-none" 
                                data-toggle="tooltip" data-placement="top" title="Editar periodo">
                            <i class="fa fa-pencil fa-fw text-white"></i></a>
                        </a>
                        <form action="<?php echo e(route('periodos.destroy',$periodo)); ?>" method="POST" class="d-inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>    
                        <button id="delete" name="delete" type="submit" 
                                    class="btn btn-dark btn-sm shadow-none" 
                                    data-toggle="tooltip" data-placement="top" title="Eliminar perido"
                                    onclick="return confirm('¿Estás seguro de eliminar?')">
                                <i class="fa fa-trash-o fa-fw"></i>
                            </button>
                        </form>
                    </td>
                    <td scope="row"><?php echo e($periodo->id_periodo); ?></td>
                    <td scope="row"><?php echo e($periodo->mes); ?></td>
                    <td scope="row"><?php echo e($periodo->estatus); ?></td>
                    
                    

                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>
        <div class="d-flex justify-content-center">
        <?php echo $periodos->links(); ?>

        </div>
    </div>
    <?php else: ?>
        <div class="alert alert-secondary">No se encontraron registros</div>
    <?php endif; ?>
    </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mi_app\resources\views/periodos/index.blade.php ENDPATH**/ ?>