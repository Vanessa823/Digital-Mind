

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
            <?php if(session('warning')): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            </div>
            <?php endif; ?>
        <div class="col-md-12">
            <div class="pull-right">
                <a class="btn btn-primary shadow-none" data-toggle="tooltip" data-placement="top" title="Inicio" href="<?php echo e(route('empleados.index')); ?>"> 
                    <i class="fa fa-home fa-fw"></i> 
                </a>
            </div>
        </div>
        <div class="col-md-12">
            <form  action="<?php echo e(route('CalificaController.store',$empleado)); ?>" method="post" class="row g-3">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
              <div class="col-md-6">
                <label class="form-label">Calificar empleado : <?php echo e($empleado->nombre_empleado); ?></label><br>
              </div>
                <div class="col-md-6">
                    <label class="form-label">Periodo: <?php echo e($periodo->mes); ?></label>
                    <input type="hidden" name="periodo" value="<?php echo e($periodo->id_periodo); ?>" required>
                </div>
                <span class="h3">Areas</span>
                
                <?php $__currentLoopData = $criteriosPorArea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="h5"><?php echo e($area['area']->nombre_area); ?></span>
                    <br>
                    <div class="col-md-1">
                        <?php if(sizeof($area['criterios']) > 0): ?>
                        <?php $__currentLoopData = $area['criterios']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div >
                            <label class="from-label"><?php echo e($criterio->nombre_criterio); ?></label>
                            <input type="hidden" name="criterio[]" value="<?php echo e($criterio->id_criterio); ?>">
                            <input type="hidden" name="area[]" value="<?php echo e($area['area']->id_area); ?>"required>
                            <input type="number" name="calificacion[]" class="form-control" required>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__errorArgs = ['tareas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger" role="alert">
                            <?php echo e($message); ?>

                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         <?php else: ?>
                    <div class="alert alert-secondary">No se encontraron criterios para calificar</div>
                    <?php $__errorArgs = ['tareas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger" role="alert">
                            <?php echo e($message); ?>

                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-12">
                <button type="submit" class="btn btn-primary">Guardar calificacion</button>
              </div>
            </form>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mi_app\resources\views/empleados/califica.blade.php ENDPATH**/ ?>