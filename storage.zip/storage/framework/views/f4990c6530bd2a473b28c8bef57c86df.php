
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="pull-right">
                <a class="btn btn-primary shadow-none" data-toggle="tooltip" data-placement="top" title="Inicio" 
                href="<?php echo e(route('proyectos.index')); ?>"> 
                    <i class="fa fa-home fa-fw"></i> 
                </a>
            </div>
        </div>
        <div class="col-md-12">
            <form  action="<?php echo e(route('proyectos.store')); ?>" method="POST" class="row g-3">
                 <?php echo csrf_field(); ?>
              <div class="col-md-6">
                <label for="descripcion" class="form-label">Nombre del proyecto</label>
                <input type="text" class="form-control shadow-none" id="nombre_proyecto" name="nombre_proyecto" value="<?php echo e(old('nombre_proyecto')); ?>">
                <?php $__errorArgs = ['nombre_proyecto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <small class="text-danger">
                        <?php echo e($message); ?>

                    </small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
              </div>
              <div class="col-md-6">
                <label for="descripcion" class="form-label">Fecha de inicio</label>
                <input type="date" class="form-control shadow-none" id="fecha_inicio" name="fecha_inicio" value="<?php echo e(old('fecha_inicio')); ?>">
                <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <small class="text-danger">
                        <?php echo e($message); ?>

                    </small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
              </div>
              <div class="col-md-6">
                <label for="descripcion" class="form-label">Fecha de entrega</label>
                <input type="date" class="form-control shadow-none" id="fecha_entrega" name="fecha_entrega" value="<?php echo e(old('fecha_entrega')); ?>">
                <?php $__errorArgs = ['fecha_entrega'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <small class="text-danger">
                        <?php echo e($message); ?>

                    </small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
              </div>
              <!-- <div class="col-md-6">
                <label for="descripcion" class="form-label">Porcentaje de avance</label>
                <input type="text" class="form-control shadow-none" id="avance" name="avance" value="<?php echo e(old('avance')); ?>">
                
              </div> -->

                <div class="col-md-6">
                <label for="tareas" class="form-label">Tareas</label><br>
                  
                <?php if(sizeof($tareas) > 0): ?>
                  <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id_tarea => $descripcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div>
                      <input type="checkbox" 
                             value="<?php echo e($id_tarea); ?>" 
                             name="tareas[]" 
                      <?php echo e(( is_array(old ( 'tareas' ) ) && in_array($id_tarea, old ('tareas' )) ) ? ' checked ' : ''); ?>>
                      <?php echo e($descripcion); ?>

                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <br>
                  <?php $__errorArgs = ['tareas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <small class="text-danger" role="alert">
                          <?php echo e($message); ?>

                      </small>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php else: ?>
                    <div class="alert alert-secondary">No se encontraron resultados.</div>
                    <?php $__errorArgs = ['tareas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger" role="alert">
                            <?php echo e($message); ?>

                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php endif; ?>
              </div>
              <div class="col-md-6">
                <label for="empleados" class="form-label">Empleados</label><br>
                  <?php if(sizeof($empleados) > 0): ?>
                  <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id_empleado => $nombre_empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                      <input type="checkbox" 
                             value="<?php echo e($id_empleado); ?>" 
                             name="empleados[]" 
                      <?php echo e(( is_array(old('empleados' ) ) && in_array($id_empleado, old('empleados' )) ) ? ' checked ' : ''); ?>>
                      <?php echo e($nombre_empleado); ?>

                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <br>
                  <?php $__errorArgs = ['empleados'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <small class="text-danger" role="alert">
                          <?php echo e($message); ?>

                      </small>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php else: ?>
                    <div class="alert alert-secondary">No se encontraron resultados.</div>
                    <?php $__errorArgs = ['empleados'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <small class="text-danger" role="alert">
                          <?php echo e($message); ?>

                      </small>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php endif; ?>
              </div>

              <div class="col-md-12">
                <button type="submit" class="btn btn-primary">Guardar</button>
              </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mi_app\resources\views/proyectos/create.blade.php ENDPATH**/ ?>