

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('success1')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success1')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('danger')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('danger')); ?>

            </div>
            <?php endif; ?>
            <div class="col-md-12">
                <div class="pull-right">
                    <a class="btn btn-primary shadow-none" data-toggle="tooltip" data-placement="top" title="Agregar empleado" href="<?php echo e(route('empleados.create')); ?>"> 
                        <i class="fa fa-plus"></i>
                    </a>
                </div>
            </div>
            <div class="col-md-12">
                <?php if(sizeof($empleados)>0): ?>
                <div class="table-responsive">
            <table class="table table-hover">
            <thead>
            <tr>
                <th scope="col">Acciones</th>
                <th scope="col">#</th>
                <th scope="col">Nombre de empleado</th>
                <th scope="col">Puesto</th>
                <th scope="col">Calificar</th>
                
                
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center" width="20%">
                        <a href="<?php echo e(route('empleados.show',$empleado)); ?>" class="btn btn-primary btn-sm shadow-none" 
                                data-toggle="tooltip" data-placement="top" title="Ver detalles">
                            <i class="fa fa-address-card fa-fw text-white"></i></a>
                        </a>
                        <a href="<?php echo e(route('empleados.edit',$empleado)); ?>" class="btn btn-warning btn-sm shadow-none" 
                                data-toggle="tooltip" data-placement="top" title="Editar empleado">
                            <i class="fa fa-pencil-square-o fa-fw "></i></a>
                        </a>
                        <form action="<?php echo e(route('empleados.destroy',$empleado)); ?>" method="POST" class="d-inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>    
                        <button id="delete" name="delete" type="submit" 
                                    class="btn btn-dark btn-sm shadow-none" 
                                    data-toggle="tooltip" data-placement="top" title="Eliminar empleado"
                                    onclick="return confirm('¿Estás seguro de eliminar?')">
                                <i class="fa fa-trash-o fa-fw text-white"></i>
                            </button>
                        </form>
                    </td>
                    <td scope="row"><?php echo e($empleado->id_empleado); ?></td>
                    <td scope="row"><?php echo e($empleado->nombre_empleado); ?></td>

                    <td scope="row"><?php echo e($empleado->puesto); ?></td>

                    <td scope="row">
                    <a href="<?php echo e(route('CalificaController.edit2',$empleado)); ?>" class="btn btn-success btn-sm shadow-none" 
                                data-toggle="tooltip" data-placement="top" title="Calificar">
                            <i class="fa fa-check-square-o"></i></a>
                        </a>
                    <a href="<?php echo e(route('calificacontroller.show',$empleado)); ?>" class="btn btn-info btn-sm shadow-none" 
                            data-toggle="tooltip" data-placement="top" title="ver">
                        <i class="fa fa-eye"></i></a>
                    </a>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center">
        <?php echo $empleados->links(); ?>

        </div>
    </div>
    <?php else: ?>
        <div class="alert alert-secondary">No se encontraron registros</div>
    <?php endif; ?>
    </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mi_app\resources\views/empleados/index.blade.php ENDPATH**/ ?>