

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
            <?php if(session('warning')): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            </div>
            <?php endif; ?>
        <div class="col-md-12">
            <div class="pull-right">
                <a class="btn btn-primary shadow-none" data-toggle="tooltip" data-placement="top" title="Inicio" href="<?php echo e(route('empleados.index')); ?>"> 
                    <i class="fa fa-home fa-fw"></i> 
                </a>
            </div>
        </div>
        <div class="col-md-6">
                <label for="descripcion" class="form-label">Nombre del Empleado :   <?php echo e($empleado->nombre_empleado); ?></label>
            </div>
        <div class="col-md-12">
            <form  action="<?php echo e(route('calificacontroller.edit2',$empleado)); ?>" method="post" class="row g-3">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
            <input type="hidden" name="id_empleado" value="<?php echo e($empleado->id_empleado); ?>">

            <div class="col-md-6">
            <label for="periodo" class="form-label">Periodo</label>
            <select id="periodo" class="form-select shadow-none" name="id_periodo" value= "">
               <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($periodo->id_periodo); ?>" <?php echo e($periodo->estatus == "actual" ? "selected": ""); ?> ><?php echo e($periodo->mes); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              </div>

            <div class="col-md-6">
            <label for="id_area" class="form-label">Area</label>
              <?php if(sizeof($areas) > 0): ?>
               <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div>
               <input value="<?php echo e($area->id_area); ?>" type="checkbox" name='id_area[]'>
               <label for="" class="form-label"><?php echo e($area->nombre_area); ?></label>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php else: ?>
               <div class="alert alert-secondary">No se encontraron resultados.</div>
               <?php endif; ?>
              </div>  
              <div class="col-md-12">
                <button type="submit" class="btn btn-primary">Ir a calificar</button>
              </div>
            </form>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mi_app\resources\views/empleados/edit2.blade.php ENDPATH**/ ?>