

<?php $__env->startSection('content'); ?>
    
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="pull-right">
                <a class="btn btn-primary shadow-none" data-toggle="tooltip" data-placement="top" 
                title="Inicio" href="<?php echo e(route('proyectos.index')); ?>"> 
                    <i class="fa fa-home fa-fw"></i> 
                </a>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card mx-auto" style="width: 100%;">
              <div class="card-header">
                Proyecto
              </div>
              <div class="card-body text">
                <h5 class="card-title"><?php echo e($proyecto->nombre_proyecto); ?></h5>
                <h5 class="card-title">Inicio <?php echo e($proyecto->fecha_inicio); ?></h5>
                <h5 class="card-title">Entrega <?php echo e($proyecto->fecha_entrega); ?></h5>
                <h5 class="card-title"><?php echo e($proyecto->avance); ?> %</h5>
                <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id_empleado => $nombre_empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($proyecto->empleados->pluck('id_empleado')->contains($id_empleado)): ?> 
                  <h5 class="card-title">Responsables:<br> <?php echo e($nombre_empleado); ?></h5>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
        </div>
           <div class="col-md-12">
                  
                <?php if(sizeof($tareas) > 0): ?>
                
              <div class="table-responsive">
              <table class="table table-hover">
              <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Tareas asignadas</th>
                <th scope="col">Estado</th>
            </tr>
            </thead>
            <tbody>
                  <?php $__currentLoopData = $proyecto->tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                
                      <td scope="row"><?php echo e($tarea->id_tarea); ?> </td>
                      <td scope="row"><?php echo e($tarea->descripcion); ?> </td>
                      <td scope="row"><?php echo e($tarea->pivot->estado); ?> </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  </table>
                  <br>
                  <?php $__errorArgs = ['tareas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger" role="alert">
                            <?php echo e($message); ?>

                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php else: ?>
                    <div class="alert alert-secondary">No se encontraron resultados.</div>
                    <?php $__errorArgs = ['tareas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger" role="alert">
                            <?php echo e($message); ?>

                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php endif; ?>
              </div>
              
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mi_app\resources\views/proyectos/show.blade.php ENDPATH**/ ?>