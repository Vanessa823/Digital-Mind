

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('success1')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success1')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('danger')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('danger')); ?>

            </div>
            <?php endif; ?>
            <div class="col-md-12">
                <div class="pull-right">
                    <a class="btn btn-primary shadow-none" data-toggle="tooltip" data-placement="top" title="Agregar Tarea" href="<?php echo e(route('tareas.create')); ?>"> 
                        <i class="fa fa-plus"></i>
                    </a>
                </div>
            </div>
            <div class="col-md-12">
                <?php if(sizeof($tareas)>0): ?>
                <div class="table-responsive">
            <table class="table table-hover">
            <thead>
            <tr>
                <th scope="col">Acciones</th>
                <th scope="col">#</th>
                <th scope="col">Tareas</th>
            
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center" width="20%">
                        <a href="<?php echo e(route('tareas.edit',$tarea)); ?>" class="btn btn-success btn-sm shadow-none" 
                                data-toggle="tooltip" data-placement="top" title="Editar tarea">
                            <i class="fa fa-pencil fa-fw text-white"></i></a>
                        </a>
                        <form action="<?php echo e(route('tareas.destroy',$tarea)); ?>" method="POST" class="d-inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>    
                        <button id="delete" name="delete" type="submit" 
                                    class="btn btn-danger btn-sm shadow-none" 
                                    data-toggle="tooltip" data-placement="top" title="Eliminar tarea"
                                    onclick="return confirm('¿Estás seguro de eliminar?')">
                                <i class="fa fa-trash-o fa-fw"></i>
                            </button>
                        </form>
                    </td>
                    <td scope="row"><?php echo e($tarea->id_tarea); ?></td>
                    <td scope="row"><?php echo e($tarea->descripcion); ?></td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center">
        <?php echo $tareas->links(); ?>

        </div>
    </div>
    <?php else: ?>
        <div class="alert alert-secondary">No se encontraron registros</div>
    <?php endif; ?>
    </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mi_app\resources\views/tareas/index.blade.php ENDPATH**/ ?>