

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <span class="h5 mb-5">Empleado: <?php echo e($empleado->nombre_empleado); ?></span>
            <form action="<?php echo e(route('calificacontroller.show',$empleado->id_empleado)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-8 mb-2 row">
                        <label class="form-label col-md-5">Periodo</label>
                        <div class="col-md-6">
                            <select name="periodo" class="form-select" required>
                                <option value="" select>Seleccionar...</option>
                                <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($periodo->id_periodo); ?>" <?php echo e(isset($actual)?($periodo->id_periodo == $actual ? "selected" : "" ):""); ?>><?php echo e($periodo->mes); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                    </div>
                    <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">Ver Calificacion</button>
                </div>
            </form>
            <?php if(isset($calificacionesPorArea)): ?>
                <span class="h4">Calificaciones</span>
                <?php $__currentLoopData = $calificacionesPorArea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="h5"><?php echo e($area['area']->nombre_area); ?></span>
                    <?php $__currentLoopData = $area['criterios']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span><?php echo e($criterio->nombre_criterio); ?> : <?php echo e($criterio->calificacion); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mi_app\resources\views/empleados/info.blade.php ENDPATH**/ ?>